# Square Mart (GitHub Pages)

Static site (HTML/CSS/images) for GitHub Pages.

## Enable GitHub Pages
Repo **Settings → Pages**
- Source: Deploy from a branch
- Branch: `master` (or `main`)
- Folder: `/ (root)`
